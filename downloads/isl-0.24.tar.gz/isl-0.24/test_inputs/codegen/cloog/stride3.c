for (int c0 = max(1, m); c0 <= n; c0 += 1)
  S1(c0);
