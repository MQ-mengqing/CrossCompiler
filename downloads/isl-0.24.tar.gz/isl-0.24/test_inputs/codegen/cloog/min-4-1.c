for (int c0 = max(-M, -N); c0 <= min(N, O); c0 += 1)
  S1(c0);
