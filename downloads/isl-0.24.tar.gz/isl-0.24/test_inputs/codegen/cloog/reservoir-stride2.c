for (int c0 = 2; c0 <= M; c0 += 7)
  S1(c0, (c0 - 2) / 7);
