for (int c0 = 1; c0 <= n; c0 += 1)
  S1(c0);
