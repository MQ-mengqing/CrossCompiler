for (int c0 = 0; c0 <= 10; c0 += 1) {
  S2(c0);
  S1(c0);
}
