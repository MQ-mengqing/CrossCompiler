for (int c0 = 0; c0 <= max(0, M); c0 += 1) {
  if (M >= c0)
    S1(c0);
  if (c0 == 0)
    S2(0);
}
