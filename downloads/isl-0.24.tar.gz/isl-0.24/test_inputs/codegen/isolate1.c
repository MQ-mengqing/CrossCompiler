for (int c0 = 0; c0 <= 3; c0 += 1)
  A(c0);
for (int c0 = 4; c0 <= 6; c0 += 1)
  A(c0);
for (int c0 = 7; c0 <= 99; c0 += 1)
  A(c0);
