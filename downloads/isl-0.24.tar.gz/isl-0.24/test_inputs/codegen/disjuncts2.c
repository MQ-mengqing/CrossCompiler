if (P >= Q + 1 || Q >= P + 1)
  for (int c0 = 0; c0 < N; c0 += 1)
    S(c0);
