if (n >= m + 1) {
  for (int c0 = 0; c0 < n; c0 += 1)
    for (int c2 = 0; c2 < n; c2 += 1)
      A(c0, c2);
} else {
  for (int c0 = 0; c0 < n; c0 += 1)
    for (int c2 = 0; c2 < n; c2 += 1)
      A(c0, c2);
}
