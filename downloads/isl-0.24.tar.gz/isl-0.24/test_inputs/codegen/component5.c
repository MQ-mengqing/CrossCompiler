for (int c0 = 0; c0 <= 9; c0 += 1)
  for (int c1 = 0; c1 <= 9; c1 += 1) {
    if (c0 == 0)
      A(c1);
    B(c0, c1);
  }
