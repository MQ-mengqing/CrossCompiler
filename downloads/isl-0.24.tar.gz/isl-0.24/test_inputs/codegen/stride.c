for (int c0 = 0; c0 <= 100; c0 += 2) {
  for (int c3 = 0; c3 <= 100; c3 += 1)
    A(c0, c3);
  for (int c2 = 0; c2 <= 100; c2 += 1)
    B(c0, c2);
}
