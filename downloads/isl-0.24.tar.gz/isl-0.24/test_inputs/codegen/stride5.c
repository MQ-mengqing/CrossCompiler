if (n % 2 == 0)
  for (int c0 = (-n / 2) + 2 * floord(n - 1, 4) + 2; c0 <= 100; c0 += 2)
    S(c0);
