for (int c0 = 0; c0 <= 10; c0 += 1) {
  S0(c0);
  if (c0 == 5)
    S2();
  S1(c0);
}
