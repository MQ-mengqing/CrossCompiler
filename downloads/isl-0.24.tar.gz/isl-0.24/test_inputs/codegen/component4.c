for (int c1 = 0; c1 <= 9; c1 += 1)
  A(c1);
for (int c0 = 0; c0 <= 9; c0 += 1)
  for (int c2 = 0; c2 <= 9; c2 += 1)
    B(c0, c2);
