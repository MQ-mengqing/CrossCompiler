#include <isl_bound.h>

isl_stat isl_qpolynomial_bound_on_domain_bernstein(
	__isl_take isl_basic_set *bset, __isl_take isl_qpolynomial *poly,
	struct isl_bound *bound);
